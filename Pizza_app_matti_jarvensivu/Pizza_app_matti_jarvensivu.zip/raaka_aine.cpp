#include "raaka_aine.h"
Raaka_aine::Raaka_aine(){}

Raaka_aine::Raaka_aine(string a){
	this->nimi=a;
}
string Raaka_aine::Getnimi(){

	return nimi;
}