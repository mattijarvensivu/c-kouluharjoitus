#ifndef RAAKA_H
#define RAAKA_H
using namespace std;
#include <vector>
class Raaka_aine{
private:
	string nimi;
public:
	Raaka_aine();
	Raaka_aine(string);
	string Getnimi();
};


#endif